<?php

declare(strict_types=1);

/*
 * +----------------------------------------------------------------------+
 * |                          ThinkSNS Plus                               |
 * +----------------------------------------------------------------------+
 * | Copyright (c) 2016-Present ZhiYiChuangXiang Technology Co., Ltd.     |
 * +----------------------------------------------------------------------+
 * | This source file is subject to enterprise private license, that is   |
 * | bundled with this package in the file LICENSE, and is available      |
 * | through the world-wide-web at the following url:                     |
 * | https://github.com/slimkit/plus/blob/master/LICENSE                  |
 * +----------------------------------------------------------------------+
 * | Author: Slim Kit Group <master@zhiyicx.com>                          |
 * | Homepage: www.thinksns.com                                           |
 * +----------------------------------------------------------------------+
 */

namespace Zhiyi\Plus\FileStorage\Filesystems;

use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Zhiyi\Plus\FileStorage\FileMetaInterface;
use Zhiyi\Plus\FileStorage\ResourceInterface;
use Zhiyi\Plus\FileStorage\TaskInterface;

interface FilesystemInterface
{
    /**
     * Get file meta.
     *
     * @param  \Zhiyi\Plus\FileStorage\ResourceInterface  $resource
     * @return \Zhiyi\Plus\FileStorage\FileMetaInterface
     */
    public function meta(ResourceInterface $resource): FileMetaInterface;

    /**
     * Get file response.
     *
     * @param  \Zhiyi\Plus\FileStorage\ResourceInterface  $resource
     * @param  string|null  $rule
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function response(ResourceInterface $resource, ?string $rule = null): Response;

    /**
     * Delete file.
     *
     * @param  string  $path
     * @return bool
     */
    public function delete(string $path): bool;

    /**
     * Create upload task.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Zhiyi\Plus\FileStorage\ResourceInterface  $resource
     * @return \Zhiyi\Plus\FileStorage\TaskInterface
     */
    public function createTask(Request $request, ResourceInterface $resource): TaskInterface;

    /**
     * Put a file.
     *
     * @param  string  $path
     * @param  mixed  $contents
     * @return bool
     */
    public function put(string $path, $contents): bool;
}
