<?php

/*
 * +----------------------------------------------------------------------+
 * |                          ThinkSNS Plus                               |
 * +----------------------------------------------------------------------+
 * | Copyright (c) 2016-Present ZhiYiChuangXiang Technology Co., Ltd.     |
 * +----------------------------------------------------------------------+
 * | This source file is subject to enterprise private license, that is   |
 * | bundled with this package in the file LICENSE, and is available      |
 * | through the world-wide-web at the following url:                     |
 * | https://github.com/slimkit/plus/blob/master/LICENSE                  |
 * +----------------------------------------------------------------------+
 * | Author: Slim Kit Group <master@zhiyicx.com>                          |
 * | Homepage: www.thinksns.com                                           |
 * +----------------------------------------------------------------------+
 */

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class WalletCharges extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wallet_charges', function (Blueprint $table) {
            $table
                ->increments('id');

            $table
                ->unsignedBigInteger('user_id')
                ->nullable()
                ->default(null)
                ->comment('关联用户，可不存在，例如直接支付方式等。存在便于按照用户检索。');

            $table
                ->string('channel', 100)
                ->comment('支付频道，参考 Ping++，增加 user 选项，表示站内用户凭据');

            $table
                ->string('account', 100)
                ->nullable()
                ->default(null)
                ->comment('交易账户，减项为目标账户，增项为来源账户，当 type 为 user 时，此处是用户ID');

            $table
                ->string('charge_id', 150)
                ->nullable()
                ->default(null)
                ->comment('凭据id, 来自 Ping ++ ');

            $table
                ->tinyInteger('action')
                ->unsigned()
                ->comment('类型：1 - 增加，0 - 减少');

            $table
                ->bigInteger('amount')
                ->unsigned()
                ->comment('总额');

            $table
                ->string('currency', 30)
                ->nullable()
                ->default('cny')
                ->comment('货币类型');

            $table
                ->string('subject', 255)
                ->comment('订单标题');

            $table
                ->text('body')
                ->comment('订单详情');

            $table
                ->string('transaction_no', 150)
                ->nullable()
                ->default(null)
                ->comment('平台记录ID');

            $table
                ->tinyInteger('status')
                ->unsigned()
                ->nullable()
                ->default(0)
                ->comment('状态：0 - 等待, 1 - 成功, 2 - 失败');

            $table->timestamps();
            $table->softDeletes(); // 软删除

            // 外健约束
            $table
                ->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade');

            $table->index('user_id');
            $table->index('charge_id');
            $table->index('channel');
            $table->index('account');
            $table->index('status');
            $table->index('action');
            $table->index('transaction_no');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wallet_charges');
    }
}
