# Email

If you need to use `Email` for alerting, create an alert instance in the alert instance management and select the Email plugin.

The following shows the `Email` configuration example:

![alert-email](../../../../img/alert/email-alter-setup1-en.png)

![alert-email](../../../../img/alert/email-alter-setup2-en.png)

![alert-email](../../../../img/alert/email-alter-setup3-en.png)
