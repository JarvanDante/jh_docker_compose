Workflow Relation screen shows all the existing workflows in a project and their status.

![](../../../../img/new_ui/dev/project/work-relation.png)
