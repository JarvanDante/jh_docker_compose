<!-- markdown-link-check-disable -->

# Older Versions：

#### Setup instructions,  are available for each stable version of Apache DolphinScheduler below:

### Versions: 3.1.7

#### Links： [3.1.7 Document](../3.1.7/user_doc/about/introduction.md)

### Versions: 3.1.6

#### Links： [3.1.6 Document](../3.1.6/user_doc/about/introduction.md)

### Versions: 3.1.5

#### Links： [3.1.5 Document](../3.1.5/user_doc/about/introduction.md)

### Versions: 3.1.4

#### Links： [3.1.4 Document](../3.1.4/user_doc/about/introduction.md)

### Versions: 3.1.3

#### Links： [3.1.3 Document](../3.1.3/user_doc/about/introduction.md)

### Versions: 3.1.2

#### Links： [3.1.2 Document](../3.1.2/user_doc/about/introduction.md)

### Versions: 3.1.1

#### Links： [3.1.1 Document](../3.1.1/user_doc/about/introduction.md)

### Versions: 3.1.0

#### Links： [3.1.0 Document](../3.1.0/user_doc/about/introduction.md)

### Versions: 3.0.0

#### Links： [3.0.0 Document](../3.0.0/user_doc/about/introduction.md)

### Versions: 2.0.6

#### Links： [2.0.6 Document](../2.0.6/user_doc/guide/quick-start.md)

### Versions: 2.0.5

#### Links： [2.0.5 Document](../2.0.5/user_doc/guide/quick-start.md)

### Versions: 2.0.3

#### Links： [2.0.3 Document](../2.0.3/user_doc/guide/quick-start.md)

### Versions: 2.0.2

#### Links：[2.0.2 Document](../2.0.2/user_doc/guide/quick-start.md)

### Versions: 2.0.1

#### Links：[2.0.1 Document](../2.0.1/user_doc/guide/quick-start.md)

### Versions: 2.0.0

#### Links：[2.0.0 Document](../2.0.0/user_doc/guide/quick-start.md)

### Versions：1.3.9

#### Links：[1.3.9 Document](../1.3.9/user_doc/quick-start.md)

### Versions：1.3.8

#### Links：[1.3.8 Document](../1.3.8/user_doc/quick-start.md)

### Versions：1.3.6

#### Links：[1.3.6 Document](../1.3.6/user_doc/quick-start.md)

### Versions：1.3.5

#### Links：[1.3.5 Document](../1.3.5/user_doc/quick-start.md)

### Versions：1.3.4

##### Links：[1.3.4 Document](../1.3.4/user_doc/quick-start.md)

### Versions：1.3.3

#### Links：[1.3.3 Document](../1.3.4/user_doc/quick-start.md)

### Versions：1.3.2

#### Links：[1.3.2 Document](../1.3.2/user_doc/quick-start.md)

### Versions：1.3.1

#### Links：[1.3.1 Document](../1.3.1/user_doc/quick-start.md)

### Versions：1.2.1

#### Links：[1.2.1 Document](../1.2.1/user_doc/quick-start.md)

### Versions：1.2.0

#### Links：[1.2.0 Document](../1.2.0/user_doc/quick-start.md)

### Versions：1.1.0

#### Links：[1.1.0 Document](../1.2.0/user_doc/quick-start.md)

### Versions：Dev

#### Links：[Dev Document](../dev/user_doc/about/introduction.md)

