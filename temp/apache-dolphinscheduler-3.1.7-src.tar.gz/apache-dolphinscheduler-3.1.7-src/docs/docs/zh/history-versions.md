<!-- markdown-link-check-disable -->

# 历史版本：

#### 以下是Apache DolphinScheduler每个稳定版本的设置说明。

### Versions: 3.1.7

#### Links： [3.1.7 文档](../3.1.7/user_doc/about/introduction.md)

### Versions: 3.1.6

#### Links： [3.1.6 文档](../3.1.6/user_doc/about/introduction.md)

### Versions: 3.1.5

#### Links： [3.1.5 文档](../3.1.5/user_doc/about/introduction.md)

### Versions: 3.1.4

#### Links： [3.1.4 文档](../3.1.4/user_doc/about/introduction.md)

### Versions: 3.1.3

#### Links： [3.1.3 文档](../3.1.3/user_doc/about/introduction.md)

### Versions: 3.1.2

#### Links： [3.1.2 文档](../3.1.2/user_doc/about/introduction.md)

### Versions: 3.1.1

#### Links： [3.1.1 文档](../3.1.1/user_doc/about/introduction.md)

### Versions: 3.1.0

#### Links： [3.1.0 文档](../3.1.0/user_doc/about/introduction.md)

### Versions: 3.0.0

#### Links： [3.0.0 文档](../3.0.0/user_doc/about/introduction.md)

### 版本：2.0.6

#### 地址：[2.0.6 文档](../2.0.6/user_doc/guide/quick-start.md)

### 版本：2.0.5

#### 地址：[2.0.5 文档](../2.0.5/user_doc/guide/quick-start.md)

### 版本：2.0.3

#### 地址：[2.0.3 文档](../2.0.3/user_doc/guide/quick-start.md)

### 版本：2.0.2

#### 地址：[2.0.2 文档](../2.0.2/user_doc/guide/quick-start.md)

### 版本：2.0.1

#### 地址：[2.0.1 文档](../2.0.1/user_doc/guide/quick-start.md)

### 版本：2.0.0

#### 地址：[2.0.0 文档](../2.0.0/user_doc/guide/quick-start.md)

### 版本：1.3.9

#### 地址：[1.3.9 文档](../1.3.9/user_doc/quick-start.md)

### 版本：1.3.8

#### 地址：[1.3.8 文档](../1.3.8/user_doc/quick-start.md)

### 版本：1.3.6

#### 地址：[1.3.6 文档](../1.3.6/user_doc/quick-start.md)

### 版本：1.3.5

#### 地址：[1.3.5 文档](../1.3.5/user_doc/quick-start.md)

### 版本：1.3.4

##### 地址：[1.3.4 文档](../1.3.4/user_doc/quick-start.md)

### 版本：1.3.3

#### 地址：[1.3.3 文档](../1.3.4/user_doc/quick-start.md)

### 版本：1.3.2

#### 地址：[1.3.2 文档](../1.3.2/user_doc/quick-start.md)

### 版本：1.3.1

#### 地址：[1.3.1 文档](../1.3.1/user_doc/quick-start.md)

### 版本：1.2.1

#### 地址：[1.2.1 文档](../1.2.1/user_doc/quick-start.md)

### 版本：1.2.0

#### 地址：[1.2.0 文档](../1.2.0/user_doc/quick-start.md)

### 版本：1.1.0

#### 地址：[1.1.0 文档](../1.2.0/user_doc/quick-start.md)

### 版本：Dev

#### 地址：[Dev 文档](../dev/user_doc/about/introduction.md)

