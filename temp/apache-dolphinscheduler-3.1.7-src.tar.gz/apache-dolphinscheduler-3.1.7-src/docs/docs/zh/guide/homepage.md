# 首页

Apache DolphinScheduler 首页可让您查看用户所有项目的任务状态统计、工作流状态统计和项目统计。 这是观察整个系统状态以及深入各个进程以检查任务和任务日志的每个状态的最佳方式。

![homepage](../../../img/new_ui/dev/homepage/homepage.png)
