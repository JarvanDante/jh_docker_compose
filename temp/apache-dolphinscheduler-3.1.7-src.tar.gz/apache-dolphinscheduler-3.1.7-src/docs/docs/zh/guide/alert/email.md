# Email

如果需要使用`Email`进行告警，请在告警实例管理中创建告警实例，并选择Email插件。
下面显示了 `Email` 配置示例：:
![alert-email](../../../../img/alert/email-alter-setup1-en.png)
![alert-email](../../../../img/alert/email-alter-setup2-en.png)
![alert-email](../../../../img/alert/email-alter-setup3-en.png)
