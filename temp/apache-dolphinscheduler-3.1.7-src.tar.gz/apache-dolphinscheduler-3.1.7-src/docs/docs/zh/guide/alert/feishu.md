# 飞书

如果您需要使用到飞书进行告警，请在告警实例管理里创建告警实例，选择 Feishu 插件。飞书的配置样例如下:

![alert-feishu](../../../../img/new_ui/dev/alert/alert_feishu.png)

参数配置

* Webhook

  > 复制机器人的webhook地址,如下图所示：

  ![alert-feishu-webhook](../../../../img/new_ui/dev/alert/alert_feishu_webhook.png)

[飞书：如何在群组中使用机器人？](https://www.feishu.cn/hc/zh-CN/articles/360024984973)
