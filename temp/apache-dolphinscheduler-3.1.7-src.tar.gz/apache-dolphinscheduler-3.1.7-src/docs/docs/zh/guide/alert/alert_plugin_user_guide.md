## 如何创建告警插件以及告警组

在 2.0.0 版本中，用户需要创建告警实例，在创建告警实例时，需要选择告警策略，有三个选项，成功发、失败发，以及成功和失败都发。在执行完工作流或任务时，如果触发告警，调用告警实例发送方法会进行逻辑判断，将告警实例与任务状态进行匹配，匹配则执行该告警实例发送逻辑，不匹配则过滤。创建完告警实例后，需要同告警组进行关联，一个告警组可以使用多个告警实例。
告警模块支持场景如下：
<img src="../../../../img/alert/alert_scenarios_zh.png">

使用步骤如下：

首先需要进入到安全中心，选择告警组管理，然后点击左侧的告警实例管理，然后创建一个告警实例，然后选择对应的告警插件，填写相关告警参数。

然后选择告警组管理，创建告警组，选择相应的告警实例即可。

![alert-instance01](../../../../img/new_ui/dev/alert/alert_instance01.png)
![alert-instance02](../../../../img/new_ui/dev/alert/alert_instance02.png)
![alert-instance03](../../../../img/new_ui/dev/alert/alert_instance03.png)
![alert-instance04](../../../../img/new_ui/dev/alert/alert_instance04.png)
