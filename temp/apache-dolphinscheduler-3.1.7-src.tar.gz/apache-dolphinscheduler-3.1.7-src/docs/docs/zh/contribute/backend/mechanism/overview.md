# 综述

<!-- TODO 由于 side menu 不支持多个等级，所以新建了一个leading page存放 -->
* [全局参数](global-parameter.md)
* [switch任务类型](task/switch.md)

