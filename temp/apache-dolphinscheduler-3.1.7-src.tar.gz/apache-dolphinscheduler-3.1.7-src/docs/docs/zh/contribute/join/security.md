# 安全

Apache Software Foundation在消除其软件项目中的安全性问题方面采取严格的立场。 Apache DolphinScheduler也非常关注与其功能有关的安全性问题。

如果您对DolphinScheduler的安全性有疑虑，或者发现了漏洞或潜在威胁，请发送邮件至[security@apache.org]（mailto：security@apache.org），与Apache安全团队联系。 请在电子邮件中将项目名称指定为DolphinScheduler，并提供相关问题或潜在威胁的描述。 还敦促您推荐重现和复制问题的方法。 在评估和分析调查结果之后，apache安全团队和DolphinScheduler社区将与您联系。

在公共领域公开该安全电子邮件之前，请注意在安全电子邮件中报告该安全问题。

