# DolphinScheduler for Docker and Kubernetes

* [Start Up DolphinScheduler with Docker](https://dolphinscheduler.apache.org/en-us/docs/3.1.2/guide/start/docker)
* [Start Up DolphinScheduler with Kubernetes](https://dolphinscheduler.apache.org/en-us/docs/3.1.2/guide/installation/kubernetes)

